﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DronTaxi
{
    public partial class EditProfile : Form
    {
        private Stream stream;
        private int id;

        public EditProfile(
            int pId,
           string pName1,
           string pName2,
           string pName3,
           string pEmail,
           string pPhone,
           string pDate,
           string pPassword,
           string pGender)
        {
            InitializeComponent();

            id = pId;
            textBox1.Text = pName1;
            textBox2.Text = pName2;
            textBox3.Text = pName3;
            textBox4.Text = pEmail;
            maskedTextBox1.Text = pPhone;
            maskedTextBox2.Text = pDate;
            textBox5.Text = pPassword;
            comboBox1.Text = pGender;

            button5.BackColor = ColorTranslator.FromHtml("#00BFFF");
            button5.ForeColor = ColorTranslator.FromHtml("#FFFFFF"); // красит текст
            button5.FlatAppearance.BorderSize = 2;
            button5.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button5.MouseEnter += (s, e) => { button5.BackColor = ColorTranslator.FromHtml("#0087B4"); };
            button5.MouseLeave += (s, e) => { button5.BackColor = ColorTranslator.FromHtml("#00BFFF"); };

            // кнопка СОХРАНИТЬ
            button6.BackColor = ColorTranslator.FromHtml("#7FFF7FD9");
            button6.ForeColor = ColorTranslator.FromHtml("#202020"); // красит текст
            button6.FlatAppearance.BorderSize = 2;
            button6.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button6.MouseEnter += (s, e) => {
                button6.BackColor = ColorTranslator.FromHtml("#128312D9");
                button6.ForeColor = ColorTranslator.FromHtml("#FFFFFFD9");
            };
            button6.MouseLeave += (s, e) => {
                button6.BackColor = ColorTranslator.FromHtml("#7FFF7FD9");
                button6.ForeColor = ColorTranslator.FromHtml("#202020");
            };
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog OPF = new OpenFileDialog();

            if (OPF.ShowDialog() == DialogResult.OK)
            {
                if ((stream = OPF.OpenFile()) != null)
                {
                    pictureBox1.Image = Image.FromStream(stream);
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string strError = "";

            if (!textBox4.Text.Contains("@mail.ru"))
            {
                strError += "Email должно содержать корректный email. \n";
            }


            if (textBox5.Text.Length <= 0)
            {
                strError += "Пароль должен быдь длиной неменее 6 символов. \n";
            }

            MatchCollection matches = Regex.Matches(textBox5.ToString(), @".*\d.*");
            if (matches.Count == 0)
            {
                strError += "Пароль должен содержать минимум одну цифру. \n";
            }

            matches = Regex.Matches(textBox5.ToString(), @"\b[A-Z]\w*\b");
            if (matches.Count == 0)
            {
                strError += "Пароль должен содержать минимум одну цифру. \n";
            }

            if (textBox5.Text != textBox8.Text)
            {
                strError += "Пароль подтверждён неверно. \n";
            }

            if (strError != "")
            {
                MessageBox.Show(strError, "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            } else
            {
                try
                {
                    NpgsqlCommand cmd = new NpgsqlCommand("upd_user", dbConnection.sqlConn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("p_email", NpgsqlDbType.Varchar).Value = textBox4.Text;
                    cmd.Parameters.Add("p_password", NpgsqlDbType.Varchar).Value = textBox5.Text;
                    cmd.Parameters.Add("p_name1", NpgsqlDbType.Varchar).Value = textBox1.Text;
                    cmd.Parameters.Add("p_name2", NpgsqlDbType.Varchar).Value = textBox2.Text;
                    cmd.Parameters.Add("p_name3", NpgsqlDbType.Varchar).Value = textBox3.Text;
                    cmd.Parameters.Add("p_date", NpgsqlDbType.Date).Value = Convert.ToDateTime(maskedTextBox2.Text);
                    cmd.Parameters.Add("p_gender", NpgsqlDbType.Varchar).Value = comboBox1.Text;
                    cmd.Parameters.Add("p_phone", NpgsqlDbType.Varchar).Value = maskedTextBox1.Text;
                    cmd.Parameters.Add("p_id_user", NpgsqlDbType.Integer).Value = id;
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Данные о пользователе успешно обновлены",
                        "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
                }
            }

            
        }
    }
}
