﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DronTaxi
{
    public partial class AddNewUserForm : Form
    {
        private Stream stream;
        private int mode;
        private int id;

        public AddNewUserForm(int pMode,
            int pId,
           string pName1,
           string pName2,
           string pName3,
           string pEmail,
           string pPhone,
           string pPassword,
           string pDate,
           string pGender)
        {
            InitializeComponent();

            mode = pMode;
            id = pId;
            textBox1.Text = pName1;
            textBox2.Text = pName2;
            textBox3.Text = pName3;
            textBox4.Text = pEmail;
            maskedTextBox1.Text = pPhone;
            maskedTextBox2.Text = pDate;
            textBox5.Text = pPassword;
            comboBox1.Text = pGender;

            Load1();

            button3.BackColor = ColorTranslator.FromHtml("#00BFFF");
            button3.ForeColor = ColorTranslator.FromHtml("#FFFFFF"); // красит текст
            button3.FlatAppearance.BorderSize = 2;
            button3.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button3.MouseEnter += (s, e) => { button3.BackColor = ColorTranslator.FromHtml("#0087B4"); };
            button3.MouseLeave += (s, e) => { button3.BackColor = ColorTranslator.FromHtml("#00BFFF"); };

            button5.BackColor = ColorTranslator.FromHtml("#00BFFF");
            button5.ForeColor = ColorTranslator.FromHtml("#FFFFFF"); // красит текст
            button5.FlatAppearance.BorderSize = 2;
            button5.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button5.MouseEnter += (s, e) => { button5.BackColor = ColorTranslator.FromHtml("#0087B4"); };
            button5.MouseLeave += (s, e) => { button5.BackColor = ColorTranslator.FromHtml("#00BFFF"); };

            // кнопка СОХРАНИТЬ
            button6.BackColor = ColorTranslator.FromHtml("#7FFF7FD9");
            button6.ForeColor = ColorTranslator.FromHtml("#202020"); // красит текст
            button6.FlatAppearance.BorderSize = 2;
            button6.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button6.MouseEnter += (s, e) => {
                button6.BackColor = ColorTranslator.FromHtml("#128312D9");
                button6.ForeColor = ColorTranslator.FromHtml("#FFFFFFD9");
            };
            button6.MouseLeave += (s, e) => {
                button6.BackColor = ColorTranslator.FromHtml("#7FFF7FD9");
                button6.ForeColor = ColorTranslator.FromHtml("#202020");
            };
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string strError = "";

            if (!textBox4.Text.Contains("@mail.ru"))
            {
                strError += "Email должно содержать корректный email. \n";
            }


            if (textBox5.Text.Length <= 0)
            {
                strError += "Пароль должен быдь длиной неменее 6 символов. \n";
            }

            MatchCollection matches = Regex.Matches(textBox5.ToString(), @".*\d.*");
            if (matches.Count == 0)
            {
                strError += "Пароль должен содержать минимум одну цифру. \n";
            }

            matches = Regex.Matches(textBox5.ToString(), @"\b[A-Z]\w*\b");
            if (matches.Count == 0)
            {
                strError += "Пароль должен содержать минимум одну цифру. \n";
            }

            if (strError != "")
            {
                MessageBox.Show(strError, "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            if(mode == 1)
            {
                try
                {
                    NpgsqlCommand cmd = new NpgsqlCommand("add_user", dbConnection.sqlConn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("p_email", NpgsqlDbType.Varchar).Value = textBox4.Text;
                    cmd.Parameters.Add("p_pass", NpgsqlDbType.Varchar).Value = textBox5.Text;
                    cmd.Parameters.Add("p_name1", NpgsqlDbType.Varchar).Value = textBox1.Text;
                    cmd.Parameters.Add("p_name2", NpgsqlDbType.Varchar).Value = textBox2.Text;
                    cmd.Parameters.Add("p_name3", NpgsqlDbType.Varchar).Value = textBox3.Text;
                    cmd.Parameters.Add("p_date", NpgsqlDbType.Date).Value = Convert.ToDateTime(maskedTextBox2.Text);
                    cmd.Parameters.Add("p_gender", NpgsqlDbType.Varchar).Value = comboBox1.Text;
                    cmd.Parameters.Add("p_phone", NpgsqlDbType.Varchar).Value = maskedTextBox1.Text;
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Пользователь успешно добавлен", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
                }
            }


            if (mode == 2)
            {
                try
                {
                    NpgsqlCommand cmd = new NpgsqlCommand("upd_user", dbConnection.sqlConn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("p_email", NpgsqlDbType.Varchar).Value = textBox4.Text;
                    cmd.Parameters.Add("p_password", NpgsqlDbType.Varchar).Value = textBox5.Text;
                    cmd.Parameters.Add("p_name1", NpgsqlDbType.Varchar).Value = textBox1.Text;
                    cmd.Parameters.Add("p_name2", NpgsqlDbType.Varchar).Value = textBox2.Text;
                    cmd.Parameters.Add("p_name3", NpgsqlDbType.Varchar).Value = textBox3.Text;
                    cmd.Parameters.Add("p_date", NpgsqlDbType.Date).Value = Convert.ToDateTime(maskedTextBox2.Text);
                    cmd.Parameters.Add("p_gender", NpgsqlDbType.Varchar).Value = comboBox1.Text;
                    cmd.Parameters.Add("p_phone", NpgsqlDbType.Varchar).Value = maskedTextBox1.Text;
                    cmd.Parameters.Add("p_id_user", NpgsqlDbType.Integer).Value = id;
                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Данные о пользователе успешно обновлены", 
                        "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
                }
            }

            //stream.Position = 0;
            //sqlCmd.Parameters.Add("@pphoto", SqlDbType.Binary, (int)stream.Length).Value = stream;
            //stream.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog OPF = new OpenFileDialog();

            if (OPF.ShowDialog() == DialogResult.OK)
            {
                if ((stream = OPF.OpenFile()) != null)
                {

                    pictureBox1.Image = Image.FromStream(stream);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AddUserRoleForm form = new AddUserRoleForm(id);
            form.ShowDialog();
            Load1();
        }


        private void Load1()
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("user_role_get", dbConnection.sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("p_id", NpgsqlDbType.Integer).Value = id;
                NpgsqlDataReader reader = cmd.ExecuteReader();

                dataGridView1.Rows.Clear();
                List<string[]> ListInvBooks = new List<string[]>();

                while (reader.Read())
                {
                    ListInvBooks.Add(new string[5]);
                    ListInvBooks[ListInvBooks.Count - 1][0] = reader[0].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][1] = reader[1].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][2] = reader[2].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][3] = reader[3].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][4] = reader[4].ToString();
                }
                reader.Close();

                foreach (string[] s in ListInvBooks)
                    dataGridView1.Rows.Add(s);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
            }
        }

        private void Load2()
        {
            if(dataGridView1.SelectedRows[0].Cells[0].Value != null)
            {
                try
                {
                    NpgsqlCommand cmd = new NpgsqlCommand("cur_func_role", dbConnection.sqlConn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("pidrole", NpgsqlDbType.Integer).Value = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                    NpgsqlDataReader reader = cmd.ExecuteReader();

                    dataGridView2.Rows.Clear();
                    List<string[]> ListInvBooks = new List<string[]>();

                    while (reader.Read())
                    {
                        ListInvBooks.Add(new string[2]);
                        ListInvBooks[ListInvBooks.Count - 1][0] = reader[0].ToString();
                        ListInvBooks[ListInvBooks.Count - 1][1] = reader[1].ToString();
                    }
                    reader.Close();

                    foreach (string[] s in ListInvBooks)
                        dataGridView2.Rows.Add(s);

                    label18.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                    textBox6.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                    textBox7.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                    maskedTextBox3.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                    maskedTextBox4.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
                }
            }
            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Load2();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows[0].Cells[0].Value != null)
            {
                try
                {
                    NpgsqlCommand cmd = new NpgsqlCommand("del_user_role", dbConnection.sqlConn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("p_id_user", NpgsqlDbType.Integer).Value = id;
                    cmd.Parameters.Add("p_id_role", NpgsqlDbType.Integer).Value = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Роль успешно удалена", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Load1();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
                }
            }
        }
    }
}
