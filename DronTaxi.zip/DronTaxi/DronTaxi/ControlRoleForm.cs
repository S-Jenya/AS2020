﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DronTaxi
{
    public partial class ControlRoleForm : Form
    {
        public ControlRoleForm()
        {
            InitializeComponent();
            Load1();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AddRoleForm addRoleForm = new AddRoleForm();
            addRoleForm.ShowDialog();
            Load1();
        }

        private void Load1()
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("role_get", dbConnection.sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("p_sys_name", NpgsqlDbType.Varchar).Value = textBox1.Text;
                NpgsqlDataReader reader = cmd.ExecuteReader();

                dataGridView1.Rows.Clear();
                List<string[]> ListInvBooks = new List<string[]>();

                while (reader.Read())
                {
                    ListInvBooks.Add(new string[5]);
                    ListInvBooks[ListInvBooks.Count - 1][0] = reader[0].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][1] = reader[1].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][2] = reader[2].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][3] = reader[3].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][4] = reader[4].ToString();
                }
                reader.Close();

                foreach (string[] s in ListInvBooks)
                    dataGridView1.Rows.Add(s);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
            }
        }

        private void Load2()
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("cur_func_role", dbConnection.sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("pidrole", NpgsqlDbType.Integer).Value = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                NpgsqlDataReader reader = cmd.ExecuteReader();

                dataGridView2.Rows.Clear();
                List<string[]> ListInvBooks = new List<string[]>();

                while (reader.Read())
                {
                    ListInvBooks.Add(new string[5]);
                    ListInvBooks[ListInvBooks.Count - 1][0] = reader[0].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][1] = reader[1].ToString();
                }
                reader.Close();

                foreach (string[] s in ListInvBooks)
                    dataGridView2.Rows.Add(s);

                label2.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                textBox6.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                textBox7.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                maskedTextBox3.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                maskedTextBox4.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Load1();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Load2();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count != 0)
            {
                NpgsqlCommand cmd = new NpgsqlCommand("rol_del", dbConnection.sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("p_id_role", NpgsqlDbType.Integer).Value = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Роль успешно удалена", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Load1();
                Load2();
            }
        }
    }
}
