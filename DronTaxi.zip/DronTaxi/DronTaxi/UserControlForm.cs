﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DronTaxi
{
    public partial class UserControlForm : Form
    {
        public UserControlForm()
        {
            InitializeComponent();
            Load1();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AddNewUserForm addNewUserForm = new AddNewUserForm(1,
                0,
                "Введите фамилию",
                "Введите имя",
                "Введите отчество",

                "Введите адрес почты",
                "9 999-999-9999",
                "Введите пароль",

                "00.00.0000",
                "Женский");
            addNewUserForm.ShowDialog();
            Load1();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddNewUserForm addNewUserForm = new AddNewUserForm(2,
                Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value),
                dataGridView1.SelectedRows[0].Cells[1].Value.ToString(),
                dataGridView1.SelectedRows[0].Cells[2].Value.ToString(),
                dataGridView1.SelectedRows[0].Cells[3].Value.ToString(),

                dataGridView1.SelectedRows[0].Cells[5].Value.ToString(),
                dataGridView1.SelectedRows[0].Cells[8].Value.ToString(),
                dataGridView1.SelectedRows[0].Cells[7].Value.ToString(),

                dataGridView1.SelectedRows[0].Cells[4].Value.ToString(),
                dataGridView1.SelectedRows[0].Cells[6].Value.ToString());
            addNewUserForm.ShowDialog();
            Load1();
        }

        private void Load1()
        {

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("users_get", dbConnection.sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("p_name", NpgsqlDbType.Varchar).Value = textBox1.Text;
                NpgsqlDataReader reader = cmd.ExecuteReader();

                List<string[]> ListInvBooks = new List<string[]>();

                dataGridView1.Rows.Clear();
                while (reader.Read())
                {
                    ListInvBooks.Add(new string[9]);
                    ListInvBooks[ListInvBooks.Count - 1][0] = reader[0].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][1] = reader[1].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][2] = reader[2].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][3] = reader[3].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][4] = reader[4].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][5] = reader[5].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][6] = reader[6].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][7] = reader[7].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][8] = reader[8].ToString();
                }
                reader.Close();

                foreach (string[] s in ListInvBooks)
                    dataGridView1.Rows.Add(s);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Load1();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count != 0 && dataGridView1.SelectedRows[0].Cells[0].Value != null)
            {
                try
                {
                    NpgsqlCommand cmd = new NpgsqlCommand("del_user", dbConnection.sqlConn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("p_id_user", NpgsqlDbType.Integer).Value = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Пользователь успешно удалён", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Load1();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
                }
            }
        }
    }
}
