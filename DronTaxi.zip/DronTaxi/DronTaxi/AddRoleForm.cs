﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DronTaxi
{
    public partial class AddRoleForm : Form
    {
        public int idrole = 0;
        public int flag = 0;
        public AddRoleForm()
        {
            InitializeComponent();

            button7.BackColor = ColorTranslator.FromHtml("#00BFFF");
            button7.ForeColor = ColorTranslator.FromHtml("#FFFFFF"); // красит текст
            button7.FlatAppearance.BorderSize = 2;
            button7.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button7.MouseEnter += (s, e) => { button7.BackColor = ColorTranslator.FromHtml("#0087B4"); };
            button7.MouseLeave += (s, e) => { button7.BackColor = ColorTranslator.FromHtml("#00BFFF"); };

            // кнопка СОХРАНИТЬ
            button6.BackColor = ColorTranslator.FromHtml("#7FFF7FD9");
            button6.ForeColor = ColorTranslator.FromHtml("#202020"); // красит текст
            button6.FlatAppearance.BorderSize = 2;
            button6.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button6.MouseEnter += (s, e) => {
                button6.BackColor = ColorTranslator.FromHtml("#128312D9");
                button6.ForeColor = ColorTranslator.FromHtml("#FFFFFFD9");
            };
            button6.MouseLeave += (s, e) => {
                button6.BackColor = ColorTranslator.FromHtml("#7FFF7FD9");
                button6.ForeColor = ColorTranslator.FromHtml("#202020");
            };

            // кнопка ДОБАВИТЬ
            button3.BackColor = ColorTranslator.FromHtml("#7FFF7FD9");
            button3.ForeColor = ColorTranslator.FromHtml("#202020"); // красит текст
            button3.FlatAppearance.BorderSize = 2;
            button3.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button3.MouseEnter += (s, e) => {
                button3.BackColor = ColorTranslator.FromHtml("#128312D9");
                button3.ForeColor = ColorTranslator.FromHtml("#FFFFFFD9");
            };
            button3.MouseLeave += (s, e) => {
                button3.BackColor = ColorTranslator.FromHtml("#7FFF7FD9");
                button3.ForeColor = ColorTranslator.FromHtml("#202020");
            };

            //  load1();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if(flag == 0)
            {
                if (textBox6.Text != "" && textBox7.Text != "" && maskedTextBox3.Text != "" && maskedTextBox4.Text != "")
                {
                    try
                    {
                        NpgsqlCommand cmd = new NpgsqlCommand("role_add", dbConnection.sqlConn);
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("psysname", NpgsqlDbType.Varchar).Value = textBox6.Text;
                        cmd.Parameters.Add("pname", NpgsqlDbType.Varchar).Value = textBox7.Text;
                        cmd.Parameters.Add("pdatestart", NpgsqlDbType.Date).Value = Convert.ToDateTime(maskedTextBox3.Text);
                        cmd.Parameters.Add("pdatefinish", NpgsqlDbType.Date).Value = Convert.ToDateTime(maskedTextBox4.Text);
                        NpgsqlDataReader reader = cmd.ExecuteReader();
                        reader.Read();
                        idrole = Convert.ToInt32(reader[0]);
                        reader.Close();

                        SelectFunctionForm form = new SelectFunctionForm(idrole);
                        form.ShowDialog();

                        load1();
                        flag = 1;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
                    }
                }
                else
                {
                    MessageBox.Show("Все поля должны быть заполнены", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            } else
            {
                SelectFunctionForm form = new SelectFunctionForm(idrole);
                form.ShowDialog();

                dataGridView1.Rows.Clear();
                load1();
            }
            
            
        }

        private void load1()
        {
           
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("cur_func_role", dbConnection.sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("pidrole", NpgsqlDbType.Integer).Value = idrole;
                NpgsqlDataReader reader = cmd.ExecuteReader();

                List<string[]> ListInvBooks = new List<string[]>();

                //
                while (reader.Read())
                {
                    ListInvBooks.Add(new string[2]);
                    ListInvBooks[ListInvBooks.Count - 1][0] = reader[0].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][1] = reader[1].ToString();
                }
                reader.Close();

                foreach (string[] s in ListInvBooks)
                    dataGridView1.Rows.Add(s);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            NpgsqlCommand cmd = new NpgsqlCommand("rol_del", dbConnection.sqlConn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("p_id_role", NpgsqlDbType.Integer).Value = idrole;
            cmd.ExecuteNonQuery();
            MessageBox.Show("Операция отменена", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Hide();

            //if (dataGridView1.Rows.Count != 0)
            //{
            //    for (int i = 0; i < dataGridView1.Rows.Count; i++)
            //    {
            //        try
            //        {
            //            NpgsqlCommand cmd = new NpgsqlCommand("cur_func_role_del", dbConnection.sqlConn);
            //            cmd.CommandType = CommandType.StoredProcedure;

            //            cmd.Parameters.Add("p_id_func", NpgsqlDbType.Integer).Value = idrole;
            //            cmd.Parameters.Add("p_id_role", NpgsqlDbType.Integer).Value = Convert.ToInt32(dataGridView1.SelectedRows[i].Cells[0].Value);
            //            cmd.ExecuteNonQuery();
            //        }
            //        catch (Exception ex)
            //        {
            //            MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
            //        }
            //    }

            //    MessageBox.Show("Успешно удалено", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    load1();

            //}
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count != 0)
            {
                try
                {
                    NpgsqlCommand cmd = new NpgsqlCommand("cur_func_role_del", dbConnection.sqlConn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("p_id_func", NpgsqlDbType.Integer).Value = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                    cmd.Parameters.Add("p_id_role", NpgsqlDbType.Integer).Value = idrole ;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Успешно удалено", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dataGridView1.Rows.Clear();
                    load1();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Hide();
           
        }
    }
}
