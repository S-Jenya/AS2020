﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DronTaxi
{
    public partial class AddUserRoleForm : Form
    {
        private int id;
        public AddUserRoleForm(int pId)
        {
            InitializeComponent();
            id = pId;
            load1();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Hide();
        }

        private void load1()
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("role_add_get", dbConnection.sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;
                NpgsqlDataReader reader = cmd.ExecuteReader();

                dataGridView1.Rows.Clear();
                List<string[]> ListInvBooks = new List<string[]>();

                while (reader.Read())
                {
                    ListInvBooks.Add(new string[3]);
                    ListInvBooks[ListInvBooks.Count - 1][0] = reader[0].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][1] = reader[1].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][2] = reader[2].ToString();
                }
                reader.Close();

                foreach (string[] s in ListInvBooks)
                    dataGridView1.Rows.Add(s);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows[0].Cells[0].Value != null)
            {
                try
                {
                    NpgsqlCommand cmd = new NpgsqlCommand("add_user_role", dbConnection.sqlConn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("p_id_user", NpgsqlDbType.Integer).Value = id;
                    cmd.Parameters.Add("p_id_role", NpgsqlDbType.Integer).Value = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Роль успешно добавлена", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
                }
            }
        }
    }
}
