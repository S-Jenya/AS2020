﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DronTaxi
{
    public partial class FirstUserControl : UserControl
    {
        public FirstUserControl()
        {
            InitializeComponent();

            // кнопка РЕДАКТИРОВАТЬ
            button4.BackColor = ColorTranslator.FromHtml("#00BFFF");
            button4.ForeColor = ColorTranslator.FromHtml("#FFFFFF"); // красит текст
            button4.FlatAppearance.BorderSize = 2;
            button4.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button4.MouseEnter += (s, e) => { button4.BackColor = ColorTranslator.FromHtml("#0087B4"); };
            button4.MouseLeave += (s, e) => { button4.BackColor = ColorTranslator.FromHtml("#00BFFF"); };


        }

        private void button4_Click(object sender, EventArgs e)
        {
            //NewUserForm form = new NewUserForm();
            //form.MdiParent = this;
            //form.ShowDialog();
           // newUserControl1.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
        }

        private void newUserControl1_Load(object sender, EventArgs e)
        {

        }
    }
}
