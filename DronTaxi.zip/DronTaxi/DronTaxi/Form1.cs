﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DronTaxi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label1.BackColor = Color.Transparent;
            label2.BackColor = Color.Transparent;
            label3.BackColor = Color.Transparent;

            button1.FlatStyle = FlatStyle.Flat;
            button1.BackColor = ColorTranslator.FromHtml("#00BFFF");
            button1.ForeColor = ColorTranslator.FromHtml("#FFFFFF"); // красит текст
            button1.FlatAppearance.BorderSize = 2;
            button1.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button1.MouseEnter += (s, e) => { button1.BackColor = ColorTranslator.FromHtml("#0087B4"); };
            button1.MouseLeave += (s, e) => { button1.BackColor = ColorTranslator.FromHtml("#00BFFF"); };

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                try
                {
                    dbConnection db = new dbConnection();
                    if (db.LogIn(textBox1.Text, textBox2.Text))
                    {
                        MenuForm form = new MenuForm();
                        this.Hide();
                        form.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Пользователь не найден", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Заполните поля ввода логина и пароля!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
