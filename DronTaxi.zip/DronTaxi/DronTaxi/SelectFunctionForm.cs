﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DronTaxi
{
    public partial class SelectFunctionForm : Form
    {
        public int idrole;
        public SelectFunctionForm(int pidrole)
        {
            InitializeComponent();
            idrole = pidrole;

            button7.BackColor = ColorTranslator.FromHtml("#00BFFF");
            button7.ForeColor = ColorTranslator.FromHtml("#FFFFFF"); // красит текст
            button7.FlatAppearance.BorderSize = 2;
            button7.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button7.MouseEnter += (s, e) => { button7.BackColor = ColorTranslator.FromHtml("#0087B4"); };
            button7.MouseLeave += (s, e) => { button7.BackColor = ColorTranslator.FromHtml("#00BFFF"); };

            // кнопка СОХРАНИТЬ
            button6.BackColor = ColorTranslator.FromHtml("#7FFF7FD9");
            button6.ForeColor = ColorTranslator.FromHtml("#202020"); // красит текст
            button6.FlatAppearance.BorderSize = 2;
            button6.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button6.MouseEnter += (s, e) => {
                button6.BackColor = ColorTranslator.FromHtml("#128312D9");
                button6.ForeColor = ColorTranslator.FromHtml("#FFFFFFD9");
            };
            button6.MouseLeave += (s, e) => {
                button6.BackColor = ColorTranslator.FromHtml("#7FFF7FD9");
                button6.ForeColor = ColorTranslator.FromHtml("#202020");
            };

            load1();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Hide();
        }

        private void load1()
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("functions_get", dbConnection.sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;
                NpgsqlDataReader reader = cmd.ExecuteReader();

                dataGridView1.Rows.Clear();
                List<string[]> ListInvBooks = new List<string[]>();

                while (reader.Read())
                {
                    ListInvBooks.Add(new string[2]);
                    ListInvBooks[ListInvBooks.Count - 1][0] = reader[0].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][1] = reader[1].ToString();
                }
                reader.Close();

                foreach (string[] s in ListInvBooks)
                    dataGridView1.Rows.Add(s);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("functions_role_set", dbConnection.sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("p_id_role", NpgsqlDbType.Integer).Value = idrole;
                cmd.Parameters.Add("p_id_func", NpgsqlDbType.Integer).Value = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                cmd.ExecuteNonQuery();

                MessageBox.Show("Успешно добавлено", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Hide();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
            }
        }
    }
}
