﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DronTaxi
{
    public partial class NewUserForm : Form
    {
        private Stream stream;

        public NewUserForm()
        {
            InitializeComponent();

            button5.BackColor = ColorTranslator.FromHtml("#00BFFF");
            button5.ForeColor = ColorTranslator.FromHtml("#FFFFFF"); // красит текст
            button5.FlatAppearance.BorderSize = 2;
            button5.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button5.MouseEnter += (s, e) => { button5.BackColor = ColorTranslator.FromHtml("#0087B4"); };
            button5.MouseLeave += (s, e) => { button5.BackColor = ColorTranslator.FromHtml("#00BFFF"); };

            // кнопка СОХРАНИТЬ
            button6.BackColor = ColorTranslator.FromHtml("#7FFF7FD9");
            button6.ForeColor = ColorTranslator.FromHtml("#202020"); // красит текст
            button6.FlatAppearance.BorderSize = 2;
            button6.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button6.MouseEnter += (s, e) => {
                button6.BackColor = ColorTranslator.FromHtml("#128312D9");
                button6.ForeColor = ColorTranslator.FromHtml("#FFFFFFD9");
            };
            button6.MouseLeave += (s, e) => {
                button6.BackColor = ColorTranslator.FromHtml("#7FFF7FD9");
                button6.ForeColor = ColorTranslator.FromHtml("#202020");
            };
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
        }

        private void button5_Click(object sender, EventArgs e)
        {
            OpenFileDialog OPF = new OpenFileDialog();

            if (OPF.ShowDialog() == DialogResult.OK)
            {
                if ((stream = OPF.OpenFile()) != null)
                {

                    pictureBox1.Image = Image.FromStream(stream);
                }
            }
        }
    }
}
