﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DronTaxi
{
    public partial class MyProfileForm : Form
    {
        private int id;
        public MyProfileForm()
        {
            InitializeComponent();
            load1();
            Load12();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            EditProfile editProfile = new EditProfile(
                id,
            textBox1.Text,
            textBox2.Text,
            textBox3.Text,
            textBox4.Text,
            maskedTextBox1.Text ,
            maskedTextBox2.Text,
            textBox5.Text,
            comboBox1.Text
                );
            editProfile.ShowDialog();
            load1();
        }

        private void load1()
        {

            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("user_profil", dbConnection.sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("p_log", NpgsqlDbType.Varchar).Value = dbConnection.Log.ToString();
                cmd.Parameters.Add("p_pass", NpgsqlDbType.Varchar).Value = dbConnection.Pass.ToString();
                NpgsqlDataReader reader = cmd.ExecuteReader();

                reader.Read();

                id = Convert.ToInt32(reader[0]);
                textBox4.Text = reader[1].ToString();
                textBox5.Text = reader[2].ToString();

                textBox1.Text = reader[3].ToString();
                textBox2.Text = reader[4].ToString();
                textBox3.Text = reader[5].ToString();

                maskedTextBox2.Text = reader[6].ToString();
                comboBox1.Text = reader[7].ToString();
                maskedTextBox1.Text = reader[8].ToString();

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
            }
        }


        private void Load12()
        {
            try
            {
                NpgsqlCommand cmd = new NpgsqlCommand("user_role_get", dbConnection.sqlConn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("p_id", NpgsqlDbType.Integer).Value = id;
                NpgsqlDataReader reader = cmd.ExecuteReader();

                dataGridView1.Rows.Clear();
                List<string[]> ListInvBooks = new List<string[]>();

                while (reader.Read())
                {
                    ListInvBooks.Add(new string[5]);
                    ListInvBooks[ListInvBooks.Count - 1][0] = reader[0].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][1] = reader[1].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][2] = reader[2].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][3] = reader[3].ToString();
                    ListInvBooks[ListInvBooks.Count - 1][4] = reader[4].ToString();
                }
                reader.Close();

                foreach (string[] s in ListInvBooks)
                    dataGridView1.Rows.Add(s);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
            }
        }

        private void Load2()
        {
            if (dataGridView1.SelectedRows[0].Cells[0].Value != null)
            {
                try
                {
                    NpgsqlCommand cmd = new NpgsqlCommand("cur_func_role", dbConnection.sqlConn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("pidrole", NpgsqlDbType.Integer).Value = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                    NpgsqlDataReader reader = cmd.ExecuteReader();

                    dataGridView2.Rows.Clear();
                    List<string[]> ListInvBooks = new List<string[]>();

                    while (reader.Read())
                    {
                        ListInvBooks.Add(new string[2]);
                        ListInvBooks[ListInvBooks.Count - 1][0] = reader[0].ToString();
                        ListInvBooks[ListInvBooks.Count - 1][1] = reader[1].ToString();
                    }
                    reader.Close();

                    foreach (string[] s in ListInvBooks)
                        dataGridView2.Rows.Add(s);

                    label18.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                    textBox6.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                    textBox7.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                    maskedTextBox3.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                    maskedTextBox4.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK);
                }
            }

        }

        private void MyProfileForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Hide();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Load2();
        }
    }
}
