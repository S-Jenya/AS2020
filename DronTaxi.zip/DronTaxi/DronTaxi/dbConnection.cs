﻿using System;
using Npgsql;
using NpgsqlTypes;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DronTaxi
{
    class dbConnection
    {
        public static NpgsqlConnection sqlConn { get; set; }
        public static string Log { get; set; }
        public static string Pass { get; set; }

        public dbConnection()
        {
            string constring = "Server = localhost; Port=5432; User Id=postgres; Password=admin; Database=atom;";
            sqlConn = new NpgsqlConnection(constring);
            sqlConn.Open();
        }

        public bool LogIn(string Login, string Password)
        {
            Log = Login;
            Pass = Password;

            NpgsqlCommand pgcom = new NpgsqlCommand("login_get", sqlConn);
            pgcom.CommandType = CommandType.StoredProcedure;

            pgcom.Parameters.Add("plog", NpgsqlDbType.Varchar).Value = Login;
            pgcom.Parameters.Add("ppass", NpgsqlDbType.Varchar).Value = Password;

            NpgsqlDataReader reader = pgcom.ExecuteReader();
            reader.Read();
            bool result = Convert.ToBoolean(reader[0]);
            reader.Close();

            return result;
        }

        public static void CloseApp()
        {
            sqlConn.Close();
        }
    }
}
