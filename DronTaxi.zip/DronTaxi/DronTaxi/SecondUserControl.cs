﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DronTaxi
{
    public partial class SecondUserControl : UserControl
    {
        public SecondUserControl()
        {
            InitializeComponent();

            // кнопка ДОБАВИТЬ
            button3.BackColor = ColorTranslator.FromHtml("#00BFFF");
            button3.ForeColor = ColorTranslator.FromHtml("#FFFFFF"); // красит текст
            button3.FlatAppearance.BorderSize = 2;
            button3.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            button3.MouseEnter += (s, e) => { button3.BackColor = ColorTranslator.FromHtml("#0087B4"); };
            button3.MouseLeave += (s, e) => { button3.BackColor = ColorTranslator.FromHtml("#00BFFF"); };
        }

        private void button3_Click(object sender, EventArgs e)
        {
            NewUserForm form = new NewUserForm();
            form.ShowDialog();
        }
    }
}
