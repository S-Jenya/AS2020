﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DronTaxi
{
    public partial class MenuForm : Form
    {
        public MenuForm()
        {
            InitializeComponent();

            button1.BackColor = Color.Transparent;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = ColorTranslator.FromHtml("#FDFDFD"); // красит текст
            button1.FlatAppearance.BorderSize = 0;
            //button1.FlatAppearance.MouseDownBackColor = ColorTranslator.FromHtml("#FDFDFD");
            //// полностью блокирует подсветку при новедении
            //button1.FlatAppearance.MouseDownBackColor = Color.Transparent;
            //button1.FlatAppearance.MouseOverBackColor = Color.Transparent;
            //button1.MouseEnter += (s, e) => { button1.BackColor = ColorTranslator.FromHtml("#800080"); };
            button1.MouseLeave += (s, e) => { 
                if(ColorTranslator.FromHtml("#800080").Name != "#800080") 
                    button1.BackColor = Color.Transparent; 
            };

            button2.BackColor = Color.Transparent;
            button2.FlatStyle = FlatStyle.Flat;
            button2.ForeColor = ColorTranslator.FromHtml("#FDFDFD"); // красит текст
            button2.FlatAppearance.BorderSize = 0;
            button2.MouseLeave += (s, e) => {
                if (ColorTranslator.FromHtml("#800080").Name != "#800080")
                    button2.BackColor = Color.Transparent;
            };

            button8.BackColor = Color.Transparent;
            button8.FlatStyle = FlatStyle.Flat;
            button8.FlatAppearance.BorderSize = 0;
            button8.MouseLeave += (s, e) => { button8.BackColor = Color.Transparent; };

            button9.BackColor = Color.Transparent;
            button9.FlatStyle = FlatStyle.Flat;
            button9.FlatAppearance.BorderSize = 0;
            button9.MouseLeave += (s, e) => { button9.BackColor = Color.Transparent; };

           

            //roundButton1.BackColor = ColorTranslator.FromHtml("#00BFFF");
            //roundButton1.ForeColor = ColorTranslator.FromHtml("#FFFFFF"); // красит текст
            //roundButton1.FlatAppearance.BorderSize = 2;
            //roundButton1.FlatAppearance.BorderColor = ColorTranslator.FromHtml("#FFFFFF");
            //roundButton1.MouseEnter += (s, e) => { roundButton1.BackColor = ColorTranslator.FromHtml("#0087B4"); };
            //roundButton1.MouseLeave += (s, e) => { roundButton1.BackColor = ColorTranslator.FromHtml("#00BFFF"); };


            // задаёт бордер
            //button1.FlatAppearance.BorderSize = 1;
            //button1.FlatAppearance.BorderColor = Color.Red;

            //button1.MouseEnter += (s, e) => {
            //    button1.BackColor = System.Drawing.ColorTranslator.FromHtml("#FDFDFD");
            //};
            //button1.MouseLeave += (s, e) =>
            //{
            //    button1.BackColor = System.Drawing.ColorTranslator.FromHtml("#FDFDFD");
            //};

            //BorderStyle = System.Windows.Forms.BorderStyle.None;
            //AutoSize = false; //Allows you to change height to have bottom padding
            //Controls.Add(new Label()
            //{ Height = 1, Dock = DockStyle.Bottom, BackColor = Color.Black });

        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.BackColor = ColorTranslator.FromHtml("#800080");
            //firstUserControl1.BringToFront();
            MyProfileForm form = new MyProfileForm();
            form.ShowDialog();
        }


        private void button8_Click(object sender, EventArgs e)
        {
            UserControlForm userControlForm = new UserControlForm();
            userControlForm.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            ControlRoleForm controlRoleForm = new ControlRoleForm();
            controlRoleForm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MenuForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

    }
}
